# README
IP ADDRESS: http://3.80.127.131:8081/ and http://3.80.127.131.sslip.io:8081/

Instance ID:  i-09df7f28263415152

Public IP:    3.80.127.131

Key file:     ece326-keypair.pem

# This is our .env file (keys are hidden):

## AWS Credentials
AWS_ACCESS_KEY=xxxxxxxxxxx

AWS_SECRET_KEY=xxxxxxxxxxx

## AWS Configuration
AWS_REGION=us-east-1

KEY_NAME=ece326-keypair

SECURITY_GROUP_NAME=ece326-group5

INSTANCE_TYPE=t3.micro

UBUNTU_AMI=ami-0c398cb65a93047f2

## Google Client
GOOGLE_CLIENT_ID=xxxxxxxxxxx

GOOGLE_CLIENT_SECRET=xxxxxxxxxxx
